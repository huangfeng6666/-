import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .config import Config

db = SQLAlchemy()

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(Config)
    db.init_app(app)
    with app.app_context():
        from sqlalchemy import inspect as sa_inspect
        from .models import Role, User, Setting, CollectedRecord
        insp = sa_inspect(db.engine)
        required = ["role", "user", "setting", "item", "collected_record"]
        if not all(insp.has_table(t) for t in required):
            db.create_all()
            if not Role.query.filter_by(name="admin").first():
                db.session.add(Role(name="admin"))
            if not Role.query.filter_by(name="user").first():
                db.session.add(Role(name="user"))
            db.session.commit()
            admin_role = Role.query.filter_by(name="admin").first()
            if not User.query.filter_by(username="admin").first():
                u = User(username="admin", role=admin_role)
                u.set_password("admin123")
                db.session.add(u)
            if not Setting.query.first():
                db.session.add(Setting())
            db.session.commit()
    from .routes import bp as main_bp
    from .auth import bp as auth_bp
    from .admin import bp as admin_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(main_bp)
    return app
