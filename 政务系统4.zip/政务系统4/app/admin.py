from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from werkzeug.utils import secure_filename
from pathlib import Path
from .models import User, Role, Setting
from . import db

bp = Blueprint("admin", __name__)

def login_required():
    uid = session.get("user_id")
    return uid is not None

def admin_required():
    return session.get("role") == "admin"

@bp.before_request
def guard():
    if request.endpoint and request.endpoint.startswith("admin."):
        if not login_required():
            return redirect(url_for("auth.login"))
        if not admin_required():
            return redirect(url_for("main.index"))

@bp.route("/dashboard")
def dashboard():
    return render_template("admin/dashboard.html")

@bp.route("/users", methods=["GET", "POST"])
def users():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role_name = request.form.get("role", "user")
        role = Role.query.filter_by(name=role_name).first()
        if not role:
            role = Role(name=role_name)
            db.session.add(role)
            db.session.flush()
        u = User(username=username, role=role)
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        flash("用户已创建")
        return redirect(url_for("admin.users"))
    users = User.query.all()
    roles = Role.query.all()
    return render_template("admin/users.html", users=users, roles=roles)

@bp.route("/users/<int:uid>/delete", methods=["POST"])
def delete_user(uid):
    u = User.query.get_or_404(uid)
    db.session.delete(u)
    db.session.commit()
    return redirect(url_for("admin.users"))

@bp.route("/settings", methods=["GET", "POST"])
def settings():
    s = Setting.query.first()
    if not s:
        s = Setting()
        db.session.add(s)
        db.session.flush()
    if request.method == "POST":
        s.app_name = request.form.get("app_name", s.app_name)
        file = request.files.get("logo")
        if file and file.filename:
            filename = secure_filename(file.filename)
            upload_dir = Path(current_app.static_folder) / "uploads"
            upload_dir.mkdir(parents=True, exist_ok=True)
            path = upload_dir / filename
            file.save(path)
            s.logo_path = f"uploads/{filename}"
        db.session.commit()
        flash("设置已更新")
        return redirect(url_for("admin.settings"))
    return render_template("admin/settings.html", setting=s)

@bp.route("/roles", methods=["GET", "POST"])
def roles():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name:
            if not Role.query.filter_by(name=name).first():
                db.session.add(Role(name=name))
                db.session.commit()
        return redirect(url_for("admin.roles"))
    roles = Role.query.all()
    return render_template("admin/roles.html", roles=roles)

@bp.route("/scrape")
def scrape_page():
    return render_template("admin/scrape.html")

@bp.route("/collect")
def collect_page():
    return redirect(url_for("main.collect_page_public"))
