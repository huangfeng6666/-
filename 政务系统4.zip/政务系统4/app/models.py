from . import db
from werkzeug.security import generate_password_hash, check_password_hash

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'))
    role = db.relationship('Role')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Setting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_name = db.Column(db.String(120), default="政企智能舆情分析报告生成智能体应用系统")
    logo_path = db.Column(db.String(255))

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)

class CollectedRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(120))
    title = db.Column(db.String(500))
    summary = db.Column(db.Text)
    cover_url = db.Column(db.String(500))
    source = db.Column(db.String(120))
    original_url = db.Column(db.String(1000))
    deep_fetched = db.Column(db.Boolean, default=False)
    deep_content = db.Column(db.Text)
    saved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
