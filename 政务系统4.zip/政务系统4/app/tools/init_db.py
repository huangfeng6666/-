from app import create_app, db
from app.models import Role, User, Setting

app = create_app()

with app.app_context():
    db.create_all()
    if not Role.query.filter_by(name='admin').first():
        db.session.add(Role(name='admin'))
    if not Role.query.filter_by(name='user').first():
        db.session.add(Role(name='user'))
    db.session.commit()
    admin_role = Role.query.filter_by(name='admin').first()
    if not User.query.filter_by(username='admin').first():
        u = User(username='admin', role=admin_role)
        u.set_password('admin123')
        db.session.add(u)
    if not Setting.query.first():
        db.session.add(Setting())
    db.session.commit()
