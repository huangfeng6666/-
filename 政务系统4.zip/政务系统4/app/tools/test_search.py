from app import create_app

app = create_app()
client = app.test_client()
client.post('/login', data={'username':'admin','password':'admin123'})
r = client.get('/search?q=西昌')
print('status', r.status_code)
