from app import create_app

app = create_app()
client = app.test_client()
r = client.post('/login', data={'username':'admin','password':'admin123'}, follow_redirects=True)
print('status', r.status_code)
print('location', r.request.path)
