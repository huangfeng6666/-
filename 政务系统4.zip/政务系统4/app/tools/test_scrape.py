from app import create_app

app = create_app()
client = app.test_client()

# login
client.post('/login', data={'username': 'admin', 'password': 'admin123'})

# call api
r = client.get('/api/scrape?q=西昌')
print('status', r.status_code)
print('len', len(r.json.get('items', [])))
if r.json.get('items'):
    print('sample', r.json['items'][0])
