import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).parent
ENV_FILE = BASE_DIR / ".env" / "dev.env"
if ENV_FILE.exists():
    load_dotenv(ENV_FILE)

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
    DEFAULT_DB = (BASE_DIR / "app.db").resolve().as_posix()
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", f"sqlite:///{DEFAULT_DB}")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
