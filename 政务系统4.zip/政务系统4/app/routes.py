from flask import Blueprint, render_template, session, redirect, url_for
from .models import Item, Setting
from flask import request, jsonify
from .services.scraper import fetch_baidu_news
from flask import Response
from flask import stream_with_context
from .models import CollectedRecord
from bs4 import BeautifulSoup
import requests
from sqlalchemy import desc

bp = Blueprint("main", __name__)

@bp.route("/")
def index():
    if not session.get("user_id"):
        return redirect(url_for("auth.login"))
    try:
        s = Setting.query.first()
    except Exception:
        s = None
    return render_template("index.html", setting=s, role=session.get("role"))

@bp.route("/api/scrape")
def api_scrape():
    if not session.get("user_id"):
        return jsonify({"error": "unauthorized"}), 401
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify({"error": "missing keyword"}), 400
    try:
        data = fetch_baidu_news(q)
        return jsonify({"keyword": q, "count": len(data), "items": data})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp.route("/search")
def search():
    if not session.get("user_id"):
        return redirect(url_for("auth.login"))
    q = request.args.get("q", "").strip()
    try:
        s = Setting.query.first()
    except Exception:
        s = None
    items = fetch_baidu_news(q) if q else []
    return render_template("search.html", setting=s, role=session.get("role"), keyword=q, items=items)

@bp.route('/collect')
def collect_page_public():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))
    try:
        s = Setting.query.first()
    except Exception:
        s = None
    return render_template('collect.html', setting=s, role=session.get('role'))

@bp.route('/warehouse')
def warehouse_page():
    if not session.get('user_id'):
        return redirect(url_for('auth.login'))
    try:
        s = Setting.query.first()
    except Exception:
        s = None
    return render_template('warehouse.html', setting=s, role=session.get('role'))

@bp.route('/api/warehouse/list')
def api_warehouse_list():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    page = int(request.args.get('page', '1'))
    limit = int(request.args.get('limit', '20'))
    q = CollectedRecord.query.order_by(desc(CollectedRecord.created_at))
    total = q.count()
    items = []
    for r in q.offset((page-1)*limit).limit(limit).all():
        items.append({
            'id': r.id,
            'keyword': r.keyword,
            '标题': r.title,
            '概要': r.summary or '',
            '封面': r.cover_url or '',
            '来源': r.source or '',
            '原始URL': r.original_url or '',
            'deep_fetched': bool(r.deep_fetched),
            'saved': bool(r.saved),
            'created_at': r.created_at.isoformat() if r.created_at else ''
        })
    return jsonify({'page': page, 'limit': limit, 'total': total, 'items': items})

@bp.route('/api/warehouse/update', methods=['POST'])
def api_warehouse_update():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    payload = request.get_json(force=True) or {}
    rid = payload.get('id')
    r = CollectedRecord.query.get(rid)
    if not r:
        return jsonify({'error':'not found'}), 404
    r.title = payload.get('标题', r.title)
    r.summary = payload.get('概要', r.summary)
    r.cover_url = payload.get('封面', r.cover_url)
    r.source = payload.get('来源', r.source)
    r.original_url = payload.get('原始URL', r.original_url)
    r.deep_fetched = bool(payload.get('deep_fetched', r.deep_fetched))
    r.deep_content = payload.get('deep_content', r.deep_content)
    r.saved = bool(payload.get('saved', True))
    db.session.commit()
    return jsonify({'ok': True})

@bp.route('/api/warehouse/delete', methods=['POST'])
def api_warehouse_delete():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    payload = request.get_json(force=True) or {}
    rid = payload.get('id')
    r = CollectedRecord.query.get(rid)
    if not r:
        return jsonify({'error':'not found'}), 404
    db.session.delete(r)
    db.session.commit()
    return jsonify({'ok': True})

@bp.route('/api/warehouse/analyze', methods=['POST'])
def api_warehouse_analyze():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    payload = request.get_json(force=True) or {}
    rid = payload.get('id')
    return jsonify({'id': rid, 'status': 'pending', 'message': 'AI 分析接口已预留'})

@bp.route('/api/scrape_stream')
def api_scrape_stream():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    q = request.args.get('q','').strip()
    data = fetch_baidu_news(q)
    total = len(data)
    def gen():
        yield f"event: meta\ndata: {{\"keyword\": \"{q}\", \"total\": {total}}}\n\n"
        for i, it in enumerate(data, start=1):
            yield f"event: item\ndata: {jsonify(it).get_data(as_text=True)}\n\n"
            pct = int(i*100/total) if total else 100
            yield f"event: progress\ndata: {{\"current\": {i}, \"total\": {total}, \"percent\": {pct}}}\n\n"
        yield "event: done\ndata: {}\n\n"
    return Response(stream_with_context(gen()), mimetype='text/event-stream')

@bp.route('/api/deep_scrape', methods=['POST'])
def api_deep_scrape():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    payload = request.get_json(force=True) or {}
    url = payload.get('url','')
    try:
        r = requests.get(url, timeout=15, headers={'User-Agent': 'Mozilla/5.0'})
        r.raise_for_status()
        soup = BeautifulSoup(r.text, 'html.parser')
        article = soup.select_one('article, .article, .content, #content, .rich-text, .article-content')
        text = article.get_text('\n', strip=True) if article else soup.get_text('\n', strip=True)
        return jsonify({'deep_content': text[:8000]})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/api/save_items', methods=['POST'])
def api_save_items():
    if not session.get('user_id'):
        return jsonify({'error':'unauthorized'}), 401
    payload = request.get_json(force=True) or {}
    keyword = payload.get('keyword','')
    items = payload.get('items', [])
    saved_ids = []
    for it in items:
        rec = CollectedRecord(
            keyword=keyword,
            title=it.get('标题',''),
            summary=it.get('概要',''),
            cover_url=it.get('封面',''),
            source=it.get('来源',''),
            original_url=it.get('原始URL',''),
            deep_fetched=bool(it.get('deep_fetched')),
            deep_content=it.get('deep_content',''),
            saved=True
        )
        db.session.add(rec)
        db.session.flush()
        saved_ids.append(rec.id)
    db.session.commit()
    return jsonify({'saved_ids': saved_ids, 'count': len(saved_ids)})
