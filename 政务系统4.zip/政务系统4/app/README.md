# 项目目录与运行说明

## 目录结构

- migrations/
- tests/
- static/
- templates/
- docs/
- requirements/
- tools/
- .env/

## 环境与依赖

1. 创建虚拟环境：`python -m venv venv`
2. 安装依赖：`venv\Scripts\python.exe -m pip install -r app\requirements\base.txt`

## 初始化与运行

1. 初始化数据库：`venv\Scripts\python.exe app\tools\init_db.py`
2. 启动服务：`venv\Scripts\python.exe run.py`
3. 访问地址：`http://127.0.0.1:5000/`

## 前端资源

将 layui v2.13.2 拷贝到 `app/static/layui/`，保持默认目录结构。

## 账号与权限

- 初始管理员：用户名 `admin`，密码 `admin123`
- 角色：`admin`、`user`，后台可增删角色与用户

## 主要页面

- 登录：`/login`
- 首页：`/`（登录后，普通用户看到报表占位，管理员可进入后台）
- 后台管理：`/admin/dashboard`
- 用户管理：`/admin/users`
- 角色管理：`/admin/roles`
- 系统设置：`/admin/settings`（应用名称、LOGO 上传）
- 数据抓取：`/admin/scrape`（输入关键字，拉取百度资讯）

## 抓取模块说明

- 环境变量：`BAIDU_COOKIE` 可选；如需提升稳定性，可填浏览器 Cookie 字符串
- 接口：`GET /api/scrape?q=关键字` 返回 JSON（标题、概要、封面、原始URL、来源）
