import os
from typing import List, Dict
from urllib.parse import quote
import requests
from bs4 import BeautifulSoup

BAIDU_NEWS_URL = (
    "https://www.baidu.com/s?rtt=1&bsst=1&cl=2&tn=news&rsv_dl=ns_pc&word={keyword}"
)

DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": os.getenv(
        "SCRAPER_UA",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0 Safari/537.36",
    ),
}

def _session_with_env() -> requests.Session:
    s = requests.Session()
    s.headers.update(DEFAULT_HEADERS)
    cookie_str = os.getenv("BAIDU_COOKIE", "")
    if cookie_str:
        s.headers["Cookie"] = cookie_str
    return s

def _clean_text(s: str) -> str:
    return "".join(ch for ch in s if not (0xE000 <= ord(ch) <= 0xF8FF)).strip()

def fetch_baidu_news(keyword: str, limit: int = 20) -> List[Dict[str, str]]:
    url = BAIDU_NEWS_URL.format(keyword=quote(keyword))
    s = _session_with_env()
    r = s.get(url, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    items: List[Dict[str, str]] = []

    blocks = soup.select("div.result, div.result-op, div.news-card") or soup.find_all("div")
    for b in blocks:
        a = b.select_one("h3.c-title a, h3 a, a.news-title")
        if not a:
            continue
        title = _clean_text(a.get_text(strip=True))
        href = a.get("href") or ""
        if not href.startswith("http"):
            continue
        if "top.baidu.com/board" in href:
            continue
        if not title:
            continue
        summary_tag = b.select_one(".c-summary, .news-summary, p, .content")
        summary = _clean_text(summary_tag.get_text(strip=True)) if summary_tag else ""
        source_tag = b.select_one(".c-author, .news-source, .source, .author")
        source_text = _clean_text(source_tag.get_text(strip=True)) if source_tag else "百度资讯"
        source = source_text.split()[0] if source_text else "百度资讯"
        img_tag = b.select_one("img[src], img[data-src]")
        cover = img_tag.get("src") or img_tag.get("data-src") if img_tag else ""
        items.append({
            "标题": title,
            "概要": summary,
            "封面": cover,
            "原始URL": href,
            "来源": source,
        })
        if len(items) >= limit:
            break
    return items
