from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from .models import User, Setting
from . import db

bp = Blueprint("auth", __name__)

def get_app_name():
    try:
        s = Setting.query.first()
        return s.app_name if s else "应用系统"
    except Exception:
        return "应用系统"

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session["user_id"] = user.id
            session["role"] = user.role.name if user.role else "user"
            return redirect(url_for("main.index"))
        flash("用户名或密码错误")
    return render_template("auth/login.html", app_name=get_app_name())

@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
