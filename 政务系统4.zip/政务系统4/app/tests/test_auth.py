from app import create_app, db
from app.models import Role, User

def test_login_flow():
    app = create_app()
    with app.app_context():
        db.create_all()
        if not Role.query.filter_by(name='admin').first():
            db.session.add(Role(name='admin'))
        db.session.commit()
    client = app.test_client()
    r = client.post('/login', data={'username':'admin','password':'admin123'}, follow_redirects=False)
    assert r.status_code in (302, 303)
