## 技术/架构
- B/S 架构，后端采用 Tornado（HTTP + WebSocket），前端用 HTML5/CSS3/JS/jQuery。
- WebSocket 实现多人同房间群聊；消息协议使用 JSON，统一 type 字段。
- Emoji 直接使用通用 Unicode 表情（如 😀）；无需额外库。
- 本阶段不接入数据库，历史记录与机器人功能仅预留接口并返回占位提示。

## 目录结构
- `server/main.py`：应用入口与 Tornado 应用注册
- `server/handlers.py`：HTTP 路由（登录、配置、页面）
- `server/ws.py`：WebSocketHandler，房间/广播逻辑
- `server/rooms.py`：房间连接管理（dict: room -> set(connection)）
- `server/config_loader.py`：读取 `config/config.json`
- `config/config.json`：服务器地址列表（WebSocket 地址）
- `templates/login.html`、`templates/chat.html`：页面模板
- `static/css/styles.css`：响应式样式（仅消息区滚动）
- `static/js/login.js`、`static/js/chat.js`：前端逻辑
- `static/lib/jquery-3.7.1.min.js`：请按要求手动拷贝

## 配置文件示例
- `config/config.json`
```json
{
  "servers": [
    {"name": "本地开发", "ws": "ws://localhost:8888/ws"}
  ]
}
```

## 后端路由
- `GET /`：登录页
- `GET /chat`：聊天室页（query: `nick`, `ws`, `room`，默认 `room=main`）
- `GET /api/config`：返回服务器地址列表
- `POST /api/login`：校验昵称非空、密码等于 `123456`、服务器在配置中；成功返回重定向 URL `/chat?...`
- `GET /ws`：WebSocket 连接入口（query 携带 `room`、`nick`）

## WebSocket 协议
- 客户端 -> 服务器：
  - `{type:"join", room, nick}`：入房
  - `{type:"chat", text, nick}`：发言（包含 emoji）
  - `{type:"ping"}`：心跳
- 服务器 -> 客户端：
  - `{type:"system", text}`：系统通知（入房/离房）
  - `{type:"chat", text, from, time}`：群聊消息广播
  - `{type:"bot", text, tag, time}`：@功能占位响应（如 `@电影`）
  - `{type:"error", text}`：错误提示
- 解析 @ 指令：`@成小理 @音乐一下 @电影 @天气 @新闻 @小视频` -> 返回占位响应，如“功能接口预留，当前仅回显：<指令>”。

## 聊天室功能点
- 多人同房间群聊，入房广播上线消息、离开广播下线消息。
- 输入框支持 emoji（直接输入 Unicode）。
- 历史记录按钮返回“正在建设中”。
- 只允许消息区出现滚动条：`#messages {overflow-y:auto}`；其他区域 `overflow:hidden`。
- 退出按钮：关闭 WebSocket，跳转登录页。

## 登录页面（参照原型）
- 组件：头像占位、昵称输入、密码输入（固定校验 `123456`）、服务器下拉（从 `/api/config` 获取）。
- 选项：记住密码（localStorage 保存勾选与昵称）、自动登录预留不启用。
- 样式：圆角卡片、阴影、响应式居中；移动端窄屏自适应。

## 前端交互
- 登录页：
  - 拉取配置填充下拉；校验后跳转到 `/chat?nick=...&ws=...&room=main`。
- 聊天页：
  - 建立 WebSocket；收到 `system/chat/bot` 渲染气泡（左他右我），显示时间。
  - 输入框 Enter 发送；工具栏包含 emoji 按钮与历史记录按钮（占位）。
  - `@` 指令仅由服务器返回占位文本。

## 样式要点
- Flex 布局：顶部工具栏固定，消息区自适应高度滚动，输入区固定高度。
- 主题色与卡片风格参考 QQ/微信效果；兼容深浅背景图。
- 响应式断点（如 480/768/1024）确保布局自适应。

## 虚拟环境/启动
- Windows：
  - `python -m venv venv`
  - `./venv/Scripts/activate`
  - `pip install tornado`
  - `python server/main.py`
- 启动后访问 `http://localhost:8888/`

## 验收步骤
- 同时打开两个浏览器窗口，均用合法密码进入 `main` 房间。
- 互相发送文本与 emoji，确认消息区滚动、其他区域不滚动。
- 输入 `@电影` 等，看到占位响应。
- 点击历史记录按钮显示“正在建设中”；点击退出返回登录页。

## 后续扩展（第二阶段）
- 接入真实机器人服务（音乐/电影/天气/新闻/小视频）。
- 引入存储保存历史记录并分页加载。
- 多房间与私聊、消息已读、消息撤回。
- 登录鉴权与令牌、头像上传、用户列表、在线人数。
- 可选：切换到 Flask 提供页面与 REST，Tornado 专注 WS（或统一到 Flask-Sock）。