import json
import os
import datetime
import asyncio
import re
import urllib.parse
import httpx
from tornado.websocket import WebSocketHandler
from .rooms import RoomManager
from .ai_client import stream_chat

rooms = RoomManager()

BOT_TAGS = ['@成小理', '@音乐一下', '@电影', '@天气', '@新闻', '@小视频']

class ChatSocket(WebSocketHandler):
    def check_origin(self, origin):
        return True

    def open(self):
        self.room = self.get_argument('room', 'main')
        self.nick = self.get_argument('nick', '匿名')
        rooms.join(self.room, self)
        m = {'type': 'system', 'text': f'{self.nick} 已加入房间'}
        rooms.broadcast(self.room, json.dumps(m))

    async def on_message(self, message):
        try:
            data = json.loads(message)
        except Exception:
            self.write_message(json.dumps({'type': 'error', 'text': '格式错误'}))
            return
        t = data.get('type')
        if t == 'ping':
            self.write_message(json.dumps({'type': 'pong'}))
            return
        if t == 'join':
            return
        if t == 'chat':
            text = str(data.get('text', ''))
            now = datetime.datetime.now().strftime('%H:%M:%S')
            msg = {'type': 'chat', 'text': text, 'from': self.nick, 'time': now}
            rooms.broadcast(self.room, json.dumps(msg))
            if '@成小理' in text:
                bot_start = {'type': 'bot', 'text': '成小理正在思考…', 'tag': '@成小理', 'time': now}
                rooms.broadcast(self.room, json.dumps(bot_start))
                prompt = text.replace('@成小理', '').strip() or '你好'
                async def run_ai():
                    full = ''
                    try:
                        async for chunk in stream_chat(prompt):
                            full += chunk
                            rooms.broadcast(self.room, json.dumps({'type': 'bot_chunk', 'text': chunk, 'time': now}))
                    except Exception as e:
                        rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': f'成小理错误：{e}', 'time': now}))
                        return
                    rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': full, 'time': now}))
                asyncio.create_task(run_ai())
            elif '@电影' in text:
                m = re.search(r'@电影\s*\[(.+?)\]', text)
                if m:
                    url = m.group(1).strip()
                    enc = urllib.parse.quote(url, safe='')
                    src = f'https://jx.m3u8.tv/jiexi/?url={enc}'
                    rooms.broadcast(self.room, json.dumps({'type': 'movie', 'src': src, 'time': now}))
                else:
                    rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': '用法：@电影[完整视频地址URL]', 'time': now}))
            elif '@音乐一下' in text:
                async def run_music():
                    try:
                        async with httpx.AsyncClient(timeout=15) as client:
                            r = await client.get('https://V2.xxapi.cn/api/randomkuwo')
                            obj = r.json()
                            d = obj.get('data') or {}
                            name = d.get('name') or ''
                            singer = d.get('singer') or ''
                            url = d.get('url') or ''
                            image = d.get('image') or ''
                            rooms.broadcast(self.room, json.dumps({'type': 'music', 'name': name, 'singer': singer, 'url': url, 'image': image, 'time': now}))
                    except Exception as e:
                        rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': f'音乐接口错误：{e}', 'time': now}))
                asyncio.create_task(run_music())
            elif '@天气' in text:
                m = re.search(r'@天气\s*(?:\[(.+?)\]|(\S+))?', text)
                city = '北京'
                if m:
                    city = (m.group(1) or m.group(2) or city).strip()
                async def run_weather():
                    try:
                        async with httpx.AsyncClient(timeout=httpx.Timeout(connect=5, read=10, write=10, pool=5)) as client:
                            geo = await client.get(f'https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(city)}&count=1&language=zh&format=json')
                            g = geo.json()
                            res = (g.get('results') or [])
                            if not res:
                                rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': '未找到城市', 'time': now}))
                                return
                            item = res[0]
                            lat = item.get('latitude')
                            lon = item.get('longitude')
                            disp = item.get('name')
                            w = await client.get(f'https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true&timezone=auto')
                            obj = w.json()
                            cur = obj.get('current_weather') or {}
                            code = int(cur.get('weathercode') or 0)
                            desc_map = {
                                0: '晴', 1: '基本晴', 2: '多云', 3: '阴', 45: '雾', 48: '霾',
                                51: '毛毛雨', 53: '毛毛雨', 55: '毛毛雨', 61: '小雨', 63: '中雨', 65: '大雨',
                                71: '小雪', 73: '中雪', 75: '大雪', 80: '阵雨', 81: '阵雨', 82: '阵雨',
                                95: '雷阵雨', 96: '雷阵雨冰雹', 99: '强雷雨'
                            }
                            desc = desc_map.get(code, '天气')
                            rooms.broadcast(self.room, json.dumps({
                                'type': 'weather',
                                'city': disp or city,
                                'temperature': cur.get('temperature'),
                                'windspeed': cur.get('windspeed'),
                                'winddirection': cur.get('winddirection'),
                                'description': desc,
                                'time': now
                            }))
                    except Exception as e:
                        rooms.broadcast(self.room, json.dumps({'type': 'bot', 'text': f'天气接口错误：{e}', 'time': now}))
                asyncio.create_task(run_weather())
            elif '@新闻' in text:
                q = text.replace('@新闻', '').strip()
                type_map = {
                    '百度': 'baiduRD',
                    '微博': 'weibo',
                    '知乎': 'zhihuHot',
                    'B站': 'bilibili'
                }
                tkey = type_map.get(q, 'baiduRD')
                async def run_news():
                    try:
                        base = os.environ.get('NEWS_API_URL', 'https://api.vvhan.com/api/hotlist')
                        headers = {
                            'Accept': 'application/json',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
                            'Referer': 'https://vvhan.com/',
                            'Origin': 'https://vvhan.com',
                            'Accept-Language': 'zh-CN,zh;q=0.9'
                        }
                        timeout = httpx.Timeout(connect=5, read=15, write=10, pool=5)
                        async with httpx.AsyncClient(timeout=timeout) as client:
                            r = await client.get(base, params={'type': tkey}, headers=headers)
                            obj = r.json() if r.status_code == 200 else {}
                            data = obj.get('data') or obj.get('list') or []
                            items = []
                            for it in data[:6]:
                                title = it.get('title') or it.get('name') or ''
                                url = it.get('url') or ''
                                hot = it.get('hot') or ''
                                items.append({'title': title, 'url': url, 'hot': hot})
                            if items:
                                rooms.broadcast(self.room, json.dumps({'type': 'news', 'items': items, 'source': tkey, 'time': now}))
                                return
                            # 尝试备用接口
                            alt = os.environ.get('NEWS_API_URL_ALT', 'https://tenapi.cn/v2/hotlist')
                            r2 = await client.get(alt, params={'type': tkey}, headers=headers)
                            obj2 = r2.json() if r2.status_code == 200 else {}
                            data2 = obj2.get('data') or obj2.get('list') or []
                            items2 = []
                            for it in data2[:6]:
                                title = it.get('title') or it.get('name') or ''
                                url = it.get('url') or ''
                                hot = it.get('hot') or ''
                                items2.append({'title': title, 'url': url, 'hot': hot})
                            if items2:
                                rooms.broadcast(self.room, json.dumps({'type': 'news', 'items': items2, 'source': tkey, 'time': now}))
                                return
                            # 再尝试切换到 http 协议
                            base_http = base.replace('https://', 'http://')
                            r3 = await client.get(base_http, params={'type': tkey}, headers=headers)
                            obj3 = r3.json() if r3.status_code == 200 else {}
                            data3 = obj3.get('data') or obj3.get('list') or []
                            items3 = []
                            for it in data3[:6]:
                                title = it.get('title') or it.get('name') or ''
                                url = it.get('url') or ''
                                hot = it.get('hot') or ''
                                items3.append({'title': title, 'url': url, 'hot': hot})
                            if items3:
                                rooms.broadcast(self.room, json.dumps({'type': 'news', 'items': items3, 'source': tkey, 'time': now}))
                                return
                            # 最终回退到 HackerNews 无需密钥
                            ids = (await client.get('https://hacker-news.firebaseio.com/v0/topstories.json')).json()[:6]
                            items_hn = []
                            for sid in ids:
                                di = (await client.get(f'https://hacker-news.firebaseio.com/v0/item/{sid}.json')).json() or {}
                                title = di.get('title') or ''
                                url = di.get('url') or f"https://news.ycombinator.com/item?id={sid}"
                                items_hn.append({'title': title, 'url': url, 'hot': ''})
                            if items_hn:
                                rooms.broadcast(self.room, json.dumps({'type': 'news', 'items': items_hn, 'source': 'HackerNews', 'time': now}))
                            else:
                                raise RuntimeError('empty data after all fallbacks')
                    except Exception as e:
                        sample = [
                            {'title': '示例新闻：热点聚合接口暂不可用', 'url': 'https://news.baidu.com', 'hot': ''},
                            {'title': '你可以稍后再试或配置 NEWS_API_URL', 'url': '', 'hot': ''}
                        ]
                        rooms.broadcast(self.room, json.dumps({'type': 'news', 'items': sample, 'source': tkey, 'time': now}))
                asyncio.create_task(run_news())
            else:
                for tag in BOT_TAGS:
                    if tag in text:
                        bot = {'type': 'bot', 'text': f'功能接口预留，当前仅回显：{tag}', 'tag': tag, 'time': now}
                        rooms.broadcast(self.room, json.dumps(bot))
            return
        self.write_message(json.dumps({'type': 'error', 'text': '未知类型'}))

    def on_close(self):
        rooms.leave(self.room, self)
        m = {'type': 'system', 'text': f'{self.nick} 已离开房间'}
        rooms.broadcast(self.room, json.dumps(m))

