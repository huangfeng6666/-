import json
import urllib.parse
import tornado.web
from .config_loader import get_servers

class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('login.html')

class ConfigHandler(tornado.web.RequestHandler):
    def get(self):
        self.set_header('Content-Type', 'application/json')
        self.write(json.dumps({'servers': get_servers()}))

class LoginHandler(tornado.web.RequestHandler):
    def post(self):
        nick = self.get_body_argument('nick', '').strip()
        password = self.get_body_argument('password', '').strip()
        ws = self.get_body_argument('ws', '').strip()
        servers = [s['ws'] for s in get_servers()]
        ok = bool(nick) and password == '123456' and ws in servers
        self.set_header('Content-Type', 'application/json')
        if not ok:
            self.write(json.dumps({'ok': False, 'msg': '校验失败'}))
            return
        q = urllib.parse.urlencode({'nick': nick, 'ws': ws, 'room': 'main'})
        self.write(json.dumps({'ok': True, 'redirect': f'/chat?{q}'}))

class ChatPageHandler(tornado.web.RequestHandler):
    def get(self):
        nick = self.get_query_argument('nick', '匿名')
        ws = self.get_query_argument('ws', '')
        room = self.get_query_argument('room', 'main')
        self.render('chat.html', nick=nick, ws=ws, room=room)

