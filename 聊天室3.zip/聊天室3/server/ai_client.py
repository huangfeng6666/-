import os
import json
import asyncio
import httpx

API_URL = os.environ.get('SF_API_URL', 'https://api.siliconflow.cn/v1/chat/completions')
MODEL = os.environ.get('SF_MODEL', 'Qwen/Qwen2.5-7B-Instruct')

async def stream_chat(prompt: str):
    key = os.environ.get('SF_API_KEY')
    if not key:
        raise RuntimeError('SF_API_KEY 未设置')
    headers = {
        'Authorization': f'Bearer {key}',
        'Content-Type': 'application/json'
    }
    payload = {
        'model': MODEL,
        'stream': True,
        'temperature': 0.2,
        'max_tokens': 512,
        'messages': [
            {'role': 'system', 'content': '你是成小理，是 OODaiP 聊天室的 AI 助手。'},
            {'role': 'user', 'content': prompt}
        ]
    }
    timeout = httpx.Timeout(connect=5.0, read=120.0, write=15.0, pool=5.0)
    async with httpx.AsyncClient(timeout=timeout, http2=True) as client:
        async with client.stream('POST', API_URL, headers=headers, json=payload) as resp:
            async for chunk in resp.aiter_lines():
                if not chunk:
                    continue
                if chunk.startswith('data:'):
                    data = chunk[5:].strip()
                    if data == '[DONE]':
                        break
                    try:
                        obj = json.loads(data)
                        choices = obj.get('choices') or []
                        if choices:
                            delta = choices[0].get('delta') or choices[0].get('message') or {}
                            content = delta.get('content') or ''
                            if content:
                                yield content
                    except Exception:
                        # 忽略无法解析的片段
                        continue
