import json
import os

def load_config():
    p = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'config.json')
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_servers():
    cfg = load_config()
    return cfg.get('servers', [])

