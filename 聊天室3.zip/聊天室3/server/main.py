import tornado.ioloop
import tornado.web
from .handlers import IndexHandler, ConfigHandler, LoginHandler, ChatPageHandler
from .ws import ChatSocket
import os

def make_app():
    base = os.path.dirname(os.path.dirname(__file__))
    return tornado.web.Application([
        (r"/", IndexHandler),
        (r"/api/config", ConfigHandler),
        (r"/api/login", LoginHandler),
        (r"/chat", ChatPageHandler),
        (r"/ws", ChatSocket),
    ], template_path=os.path.join(base, 'templates'), static_path=os.path.join(base, 'static'))

if __name__ == '__main__':
    app = make_app()
    app.listen(8889)
    print('http://localhost:8889/')
    tornado.ioloop.IOLoop.current().start()

