class RoomManager:
    def __init__(self):
        self.rooms = {}

    def join(self, room, conn):
        s = self.rooms.get(room)
        if s is None:
            s = set()
            self.rooms[room] = s
        s.add(conn)

    def leave(self, room, conn):
        s = self.rooms.get(room)
        if s is None:
            return
        if conn in s:
            s.remove(conn)
        if not s:
            del self.rooms[room]

    def broadcast(self, room, msg, exclude=None):
        s = self.rooms.get(room)
        if not s:
            return
        for c in list(s):
            if exclude is not None and c is exclude:
                continue
            try:
                c.write_message(msg)
            except Exception:
                pass

