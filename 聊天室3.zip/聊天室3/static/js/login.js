(function(){
  function fetchServers(){
    return fetch('/api/config').then(function(r){return r.json()}).then(function(d){return d.servers||[]})
  }
  function fillServers(list){
    var sel=document.getElementById('server')
    sel.innerHTML=''
    list.forEach(function(it){
      var o=document.createElement('option')
      o.value=it.ws
      o.textContent=it.name+'('+it.ws+')'
      sel.appendChild(o)
    })
  }
  function restore(){
    var remember=localStorage.getItem('remember')==='1'
    var nick=localStorage.getItem('nick')||''
    var password=remember?'123456':''
    document.getElementById('remember').checked=remember
    document.getElementById('nick').value=nick
    document.getElementById('password').value=password
  }
  function showMsg(t){document.getElementById('msg').textContent=t}
  function bind(){
    document.getElementById('login').addEventListener('click',function(){
      var nick=document.getElementById('nick').value.trim()
      var password=document.getElementById('password').value.trim()
      var ws=document.getElementById('server').value
      var body=new URLSearchParams()
      body.set('nick',nick)
      body.set('password',password)
      body.set('ws',ws)
      fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()}).then(function(r){return r.json()}).then(function(d){
        if(!d.ok){showMsg('请输入合法信息且密码为123456');return}
        if(document.getElementById('remember').checked){
          localStorage.setItem('remember','1')
          localStorage.setItem('nick',nick)
        }else{
          localStorage.removeItem('remember')
          localStorage.removeItem('nick')
        }
        location.href=d.redirect
      }).catch(function(){showMsg('网络错误')})
    })
  }
  restore()
  fetchServers().then(fillServers)
  bind()
})();

