(function(){
  var nick=window.CHAT_INIT.nick
  var wsUrl=window.CHAT_INIT.ws
  var room=window.CHAT_INIT.room||'main'
  document.getElementById('roomName').textContent=room
  var socket=null
  function connect(){
    var u=wsUrl+(wsUrl.indexOf('?')>-1?'&':'?')+'room='+encodeURIComponent(room)+'&nick='+encodeURIComponent(nick)
    socket=new WebSocket(u)
    socket.addEventListener('open',function(){
      socket.send(JSON.stringify({type:'join',room:room,nick:nick}))
    })
    socket.addEventListener('message',function(ev){
      try{var d=JSON.parse(ev.data)}catch(e){return}
      if(d.type==='system'){addSystem(d.text);return}
      if(d.type==='chat'){addChat(d.from===nick?'me':'other',d.from,d.text,d.time);return}
      if(d.type==='bot'){addBot(d.text,d.time);return}
      if(d.type==='bot_chunk'){appendBotChunk(d.text);return}
      if(d.type==='movie'){addMovie(d.src,d.time);return}
      if(d.type==='music'){addMusic(d);return}
      if(d.type==='weather'){addWeather(d);return}
      if(d.type==='news'){addNews(d);return}
    })
    socket.addEventListener('close',function(){})
  }
  function addRow(cls,html){
    var r=document.createElement('div')
    r.className='msg-row '+cls
    r.innerHTML=html
    var m=document.getElementById('messages')
    m.appendChild(r)
    m.scrollTop=m.scrollHeight
  }
  function addChat(who,from,text,time){
    var name='<span class="meta">'+from+' '+(time||'')+'</span>'
    var bubble='<div class="bubble">'+escapeHtml(text)+'</div>'
    addRow(who==='me'?'right':'left',name+bubble)
  }
  function addSystem(t){
    var s=document.createElement('div')
    s.className='system'
    s.textContent=t
    var m=document.getElementById('messages')
    m.appendChild(s)
    m.scrollTop=m.scrollHeight
  }
  function addBot(t,time){
    var name='<span class="meta">机器人 '+(time||'')+'</span>'
    var bubble='<div class="bubble">'+escapeHtml(t)+'</div>'
    addRow('left',name+bubble)
    lastBotBubble = document.querySelector('#messages .msg-row.left:last-child .bubble')
  }
  var lastBotBubble=null
  var botBuffer=''
  var botFlushTimer=null
  function appendBotChunk(text){
    if(!lastBotBubble){
      addBot('', '')
    }
    botBuffer+=text
    if(botFlushTimer) return
    botFlushTimer=setTimeout(function(){
      lastBotBubble.innerHTML += escapeHtml(botBuffer)
      botBuffer=''
      botFlushTimer=null
      var m=document.getElementById('messages')
      m.scrollTop=m.scrollHeight
    },80)
  }
  function addMovie(src,time){
    var allowPrefix='https://jx.m3u8.tv/jiexi/?url='
    if(typeof src!=='string' || src.indexOf(allowPrefix)!==0){
      addBot('影片地址不合法', time);return
    }
    var name='<span class="meta">影片 '+(time||'')+'</span>'
    var bubble='<div class="bubble"><iframe src="'+encodeURI(src)+'" width="400" height="400" frameborder="0" allowfullscreen></iframe></div>'
    addRow('left',name+bubble)
  }
  function addMusic(d){
    var url=d.url||''
    var img=d.image||''
    var name=d.name||''
    var singer=d.singer||''
    if(!(url.startsWith('http://')||url.startsWith('https://'))){addBot('音乐地址不合法','');return}
    var cover='<img class="music-cover" src="'+encodeURI(img)+'" alt="cover"/>'
    var info='<div class="music-info"><div class="music-title">'+escapeHtml(name)+'</div><div class="music-singer">'+escapeHtml(singer)+'</div><audio class="music-player" src="'+encodeURI(url)+'" controls preload="none"></audio></div>'
    var bubble='<div class="bubble"><div class="music-card">'+cover+info+'</div></div>'
    var nameMeta='<span class="meta">音乐</span>'
    addRow('left',nameMeta+bubble)
  }
  function addWeather(d){
    var city=d.city||''
    var t=d.temperature
    var ws=d.windspeed
    var wd=d.winddirection
    var desc=d.description||''
    var icon='☀️'
    if(desc.indexOf('雨')>-1) icon='🌧️'
    else if(desc.indexOf('雪')>-1) icon='❄️'
    else if(desc.indexOf('雾')>-1||desc.indexOf('霾')>-1) icon='🌫️'
    else if(desc.indexOf('阴')>-1) icon='☁️'
    var bubble='<div class="bubble"><div class="weather-card"><div class="weather-icon">'+icon+'</div><div class="weather-info"><div class="weather-city">'+escapeHtml(city)+'</div><div class="weather-desc">'+escapeHtml(desc)+'，'+(t!=null?(t+'℃'):'')+'</div><div class="weather-wind">风速 '+(ws!=null?ws+' m/s':'')+' 风向 '+(wd!=null?wd+'°':'')+'</div></div></div></div>'
    var meta='<span class="meta">天气</span>'
    addRow('left',meta+bubble)
  }
  function addNews(d){
    var items=d.items||[]
    var src=d.source||''
    var meta='<span class="meta">新闻</span>'
    var list='<ul class="news-list">'+items.map(function(it){
      var t=escapeHtml(it.title||'')
      var u=it.url||''
      var hot=it.hot?('<span class="news-hot">'+escapeHtml(String(it.hot))+'</span>'):''
      var a=u?('<a href="'+encodeURI(u)+'" target="_blank" rel="noopener">'+t+'</a>'):t
      return '<li>'+a+hot+'</li>'
    }).join('')+'</ul>'
    var bubble='<div class="bubble"><div class="news-card"><div class="news-src">来源 '+escapeHtml(src)+'</div>'+list+'</div></div>'
    addRow('left',meta+bubble)
  }
  function escapeHtml(s){
    return s.replace(/[&<>"]/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]})
  }
  function send(){
    var t=document.getElementById('text').value
    if(!t||!socket||socket.readyState!==1)return
    socket.send(JSON.stringify({type:'chat',text:t,nick:nick}))
    document.getElementById('text').value=''
  }
  document.getElementById('send').addEventListener('click',send)
  document.getElementById('text').addEventListener('keydown',function(e){if(e.key==='Enter'){send()}})
  document.getElementById('exit').addEventListener('click',function(){if(socket)socket.close();location.href='/'})
  document.getElementById('history').addEventListener('click',function(){alert('历史记录正在建设中')})
  document.getElementById('emoji').addEventListener('click',function(){var p=document.getElementById('emojiPanel');p.style.display=p.style.display==='none'?'block':'none'})
  Array.prototype.forEach.call(document.querySelectorAll('.emo'),function(x){x.addEventListener('click',function(){var i=document.getElementById('text');i.value=i.value+x.textContent})})
  connect()
})();
